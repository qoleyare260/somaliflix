SOMALIFLIX starter website

Files:
- index.html: main page
- style.css: design and colors
- script.js: small JavaScript file

To publish with GitHub Pages:
1. Upload these four files to the root of your GitHub repository.
2. Open repository Settings > Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Select main and /(root), then Save.

This is a starter front-end design. It does not include a licensed movie library or streaming backend. Only upload videos you own or have permission to distribute.
